from django.apps import AppConfig


class SunirdConfig(AppConfig):
    name = 'sunird'
